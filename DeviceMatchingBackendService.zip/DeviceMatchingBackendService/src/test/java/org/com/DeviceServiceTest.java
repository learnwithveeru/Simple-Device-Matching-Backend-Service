package org.com;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.*;

import org.com.model.Device;
import org.com.model.UserAgentParser;
import org.com.repo.DeviceRepository;
import org.com.services.DeviceService;
public class DeviceServiceTest {
	@Mock
    private DeviceRepository deviceRepository;

    @Mock
    private UserAgentParser userAgentParser;

    @InjectMocks
    private DeviceService deviceService;

    @Test
    public void testMatchDevice_NewDevice() {
        String userAgentString = "Mozilla/5.0 ...";
        Device parsedDevice = new Device();
        when(userAgentParser.parseUserAgent(userAgentString)).thenReturn(parsedDevice);
        
        deviceService.matchDevice(userAgentString);
        
        verify(deviceRepository, times(1)).saveDevice(any(Device.class));
    }

   
}
