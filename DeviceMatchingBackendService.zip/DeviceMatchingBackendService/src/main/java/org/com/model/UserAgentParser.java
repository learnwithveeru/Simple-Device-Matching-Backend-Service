package org.com.model;
import eu.bitwalker.useragentutils.UserAgent;
import org.springframework.stereotype.Component;

@Component
public class UserAgentParser {

    public Device parseUserAgent(String userAgentString) {
        UserAgent userAgent = UserAgent.parseUserAgentString(userAgentString);

        String osName = userAgent.getOperatingSystem().getName();
        String osVersion = userAgent.getOperatingSystem().getDeviceType().getName();
        String browserName = userAgent.getBrowser().getName();
        String browserVersion = userAgent.getBrowserVersion().getVersion();

        Device device = new Device();
        device.setOsName(osName);
        device.setOsVersion(osVersion);
        device.setBrowserName(browserName);
        device.setBrowserVersion(browserVersion);
        device.setHitCount(1);

        return device;
    }
}
