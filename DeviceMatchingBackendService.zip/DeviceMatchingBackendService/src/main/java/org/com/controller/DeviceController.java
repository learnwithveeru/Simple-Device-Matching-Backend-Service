package org.com.controller;
import org.com.model.Device;
import org.com.services.DeviceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/device")
public class DeviceController {

    @Autowired
    private DeviceService deviceService;

    @PostMapping("/match")
    public ResponseEntity<Device> matchDevice(@RequestHeader("User-Agent") String userAgent) {
        Device matchedDevice = deviceService.matchDevice(userAgent);
        return ResponseEntity.ok(matchedDevice);
    }

    @GetMapping("/{deviceId}")
    public ResponseEntity<Device> getDeviceById(@PathVariable String deviceId) {
        Device device = deviceService.getDeviceById(deviceId);
        return ResponseEntity.ok(device);
    }

    @DeleteMapping("/{deviceId}")
    public ResponseEntity<Void> deleteDeviceById(@PathVariable String deviceId) {
        deviceService.deleteDeviceById(deviceId);
        return ResponseEntity.noContent().build();
    }
}
