package org.com;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeviceMatchingBackendServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
