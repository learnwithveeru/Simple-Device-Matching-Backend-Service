package org.com.services;
import java.util.UUID;
import org.com.model.Device;
import org.com.model.UserAgentParser;
import org.com.repo.DeviceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class DeviceService {
	@Autowired
    private DeviceRepository deviceRepository;

    @Autowired
    private UserAgentParser userAgentParser;

    public Device matchDevice(String userAgentString) {
        Device parsedDevice = userAgentParser.parseUserAgent(userAgentString);
        
        // Try to find a matching device
        Device existingDevice = findMatchingDevice(parsedDevice);
        
        if (existingDevice != null) {
            // Increment hit count and update in database
            existingDevice.setHitCount(existingDevice.getHitCount() + 1);
            deviceRepository.updateHitCount(existingDevice);
            return existingDevice;
        }

        // If no match, save the new device
        parsedDevice.setDeviceId(UUID.randomUUID().toString());
        deviceRepository.saveDevice(parsedDevice);
        return parsedDevice;
    }

    public Device getDeviceById(String deviceId) {
        return deviceRepository.getDeviceById(deviceId);
    }

    public void deleteDeviceById(String deviceId) {
        deviceRepository.deleteDeviceById(deviceId);
    }

    private Device findMatchingDevice(Device device) {
        
        return null; 
    }
}
