package org.com.repo;
import com.aerospike.client.Bin;
import com.aerospike.client.Key;
import com.aerospike.client.Record;
import com.aerospike.client.AerospikeClient;
import com.aerospike.client.policy.WritePolicy;

import org.com.model.Device;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class DeviceRepository {

    @Autowired
    private AerospikeClient aerospikeClient;

    private static final String NAMESPACE = "test";
    private static final String SET_NAME = "devices";

    public void saveDevice(Device device) {
        Key key = new Key(NAMESPACE, SET_NAME, device.getDeviceId());
        Bin osNameBin = new Bin("osName", device.getOsName());
        Bin osVersionBin = new Bin("osVersion", device.getOsVersion());
        Bin browserNameBin = new Bin("browserName", device.getBrowserName());
        Bin browserVersionBin = new Bin("browserVersion", device.getBrowserVersion());
        Bin hitCountBin = new Bin("hitCount", device.getHitCount());
        
        aerospikeClient.put(new WritePolicy(), key, osNameBin, osVersionBin, browserNameBin, browserVersionBin, hitCountBin);
    }

    public Device getDeviceById(String deviceId) {
        Key key = new Key(NAMESPACE, SET_NAME, deviceId);
        Record record = aerospikeClient.get(null, key);
        
        if (record != null) {
            return new Device(
                deviceId,
                record.getString("osName"),
                record.getString("osVersion"),
                record.getString("browserName"),
                record.getString("browserVersion"),
                record.getInt("hitCount")
            );
        }
        return null;
    }

    public void deleteDeviceById(String deviceId) {
        Key key = new Key(NAMESPACE, SET_NAME, deviceId);
        aerospikeClient.delete(null, key);
    }

    public void updateHitCount(Device device) {
        device.setHitCount(device.getHitCount() + 1);
        saveDevice(device);
    }
}
